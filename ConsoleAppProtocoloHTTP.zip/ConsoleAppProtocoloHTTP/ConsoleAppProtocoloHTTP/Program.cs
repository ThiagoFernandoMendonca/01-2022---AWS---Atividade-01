﻿using System;

namespace ConsoleAppProtocoloHTTP
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            ServiceReference1.SOAPDemoSoapClient soapClient = new ServiceReference1.SOAPDemoSoapClient();

          
            bool Continue = true;

            while (Continue)
{
                Console.WriteLine("Call the service DivideIntege (d)");
                Console.WriteLine("Call the service AddInteger (a)");
                Console.WriteLine("Call the service FindPerson (f)");
                Console.WriteLine("Exit (e)");

                string menu = Console.ReadLine();

                switch (menu)
                {
                    case "d":

                         var response = soapClient.DivideIntegerAsync(20, 5);

                        Console.WriteLine(response.Result.ToString());
                        Console.ReadLine();
                        break;

                    case "a":

                         var response2 = soapClient.AddIntegerAsync(5, 5);

                         Console.WriteLine(response2.Result.ToString());
                        Console.ReadLine();
                        break;

                    case "f":

                        var response3 = soapClient.FindPersonAsync("1");

                        Console.WriteLine(response3.Result.Name);
                        Console.ReadLine();

                        break;

                    case "e":
                    default:
                        Continue = false;
                        break;
                }
            }


        }
    }
}
